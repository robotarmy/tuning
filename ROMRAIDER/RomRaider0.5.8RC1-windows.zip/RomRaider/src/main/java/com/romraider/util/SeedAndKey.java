package com.romraider.util;

import java.awt.EventQueue;
/**
 * From ROM A2WC522S: Sub_47AAC
 * @author Dale
 *
 */
public class SeedAndKey {
    private final static short[] LUT_w_4EBB8 = {
            (short) 0x53DA, (short) 0x33BC, (short) 0x72EB, (short) 0x437D,
            (short) 0x7CA3, (short) 0x3382, (short) 0x834F, (short) 0x3608,
            (short) 0xAFB8, (short) 0x503D, (short) 0xDBA3, (short) 0x9D34,
            (short) 0x3563, (short) 0x6B70, (short) 0x6E74, (short) 0x88F0
    };
    private final static short[] LUT_COBB1 = {
            (short) 0xAA74, (short) 0xF6D9, (short) 0xECAB, (short) 0x8B17,
            (short) 0x6155, (short) 0xA6D2, (short) 0x496C, (short) 0x75B8,
            (short) 0x9F2C, (short) 0x7B27, (short) 0xC6D1, (short) 0xB485,
            (short) 0x22B0, (short) 0x90D4, (short) 0xA684, (short) 0x60BB
    };
	private final static short[] LUT_w_4EBD8 = {
			(short) 0x24B9, (short) 0x9D91, (short) 0xFF0C, (short) 0xB8D5,
			(short) 0x15BB, (short) 0xF998, (short) 0x8723, (short) 0x9E05,
			(short) 0x7092, (short) 0xD683, (short) 0xBA03, (short) 0x59E1,
			(short) 0x6136, (short) 0x9B9A, (short) 0x9CFB, (short) 0x9DDB
	};
    private final static short[] LUT_COBB2 = {
            (short) 0x77C1, (short) 0x80BB, (short) 0xD5C1, (short) 0x7A94,
            (short) 0x11F0, (short) 0x25FF, (short) 0xC365, (short) 0x10B4,
            (short) 0x48DA, (short) 0x6720, (short) 0x3255, (short) 0xFA17,
            (short) 0x60BF, (short) 0x780E, (short) 0xFC1D, (short) 0x5A28
    };
    private final static short[] LUT_BRZ = {
            (short) 0xad6b, (short) 0x35f4, (short) 0xfd21,
            (short) 0x78b1, (short) 0x4625, (short) 0x201c, (short) 0x9ea5,
            (short) 0xad6b, (short) 0x35f4, (short) 0xfd21, (short) 0x5e71,
            (short) 0xb046, (short) 0x7f4a, (short) 0x4b75, (short) 0x93f9,
            (short) 0x1895, (short) 0x8961, (short) 0x3ecc, (short) 0x862b
            // maybe seed of 0x0000CB = Key of 0xBA583B91
    };
    private final static byte[] LUT_b_4EBF8 = {
			0x05, 0x06, 0x07, 0x01, 0x09, 0x0C, 0x0D, 0x08,
			0x0A, 0x0D, 0x02, 0x0B, 0x0F, 0x04, 0x00, 0x03,
			0x0B, 0x04, 0x06, 0x00, 0x0F, 0x02,	0x0D, 0x09,
			0x05, 0x0C, 0x01, 0x0A, 0x03, 0x0D, 0x0E, 0x08
	};

	public SeedAndKey() {
	}

	/**
	 * This sub calculates the Seed from int32 retrieved from ATU-II TCNT0H
	 * channel 0 free run counter.  This does funky stuff to calculate the Seed.
	 * The Seed is sent to the tester and it is required to calculate the Key
	 * from it.  The Key will be the original TCNT0H value.
	 * @param TCNT0H - the Key
	 * @return the Seed to send to the tester.
	 */
    protected int encrypt(int key) {
        return encrypt(key, LUT_w_4EBB8);
    }
	protected int encrypt(int key, short[] lut) {
		short key_hi;
		int key_low;
		int interation = 1;
		for (int it : lut) {
			key_hi =  (short) (key >>> 16);
			key_low = key & 0x0000FFFF;
			int returnValue = convert(key_low, it, LUT_b_4EBF8);
			int newValue_low_w = returnValue ^ key_hi;
			int newValue_hi_w = key_low << 16;
			key = newValue_hi_w + (newValue_low_w & 0x0000FFFF);
			interation++;
		}
		int resultH = (key << 16) & 0xFFFF0000;
		int resultL = (key >>> 16) & 0x0000FFFF;
		int result = resultH + resultL;
		return result;
	}

    public int decrypt(int seed) {
        return decrypt(seed, LUT_COBB1);
    }
    protected int decrypt(int seed, short[] lut) {
        short seed_hi;
        int seed_low;
        int interation = 1;
        for (int it = (lut.length - 1); it >= 0; it--) {
            seed_hi =  (short) (seed >>> 16);
            seed_low = seed & 0x0000FFFF;
            int returnValue = convert(seed_low, lut[it], LUT_b_4EBF8);
            int newValue_low_w = returnValue ^ seed_hi;
            int newValue_hi_w = seed_low << 16;
            seed = newValue_hi_w + (newValue_low_w & 0x0000FFFF);
            interation++;
        }
        int resultH = (seed << 16) & 0xFFFF0000;
        int resultL = (seed >>> 16) & 0x0000FFFF;
        int result = resultH + resultL;
        return result;
    }

    /**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SeedAndKey sub = new SeedAndKey();
                   int[] seeds = {
                            0x23671a97, 0x0a90b266, 0xc7699cef,
                            0x62455e76, 0x59648118, 0xe700480d
                    };
					int[] keys = {
					        0x05cfad17, 0x00a63512, 0x00a2f804,
					        0x0082239e, 0x1c6cfc76, 0x0083f7ad
					};
					for (int key : keys) {
					    System.out.printf("from keys: 0x%08x, calc seed: 0x%08x%n",
					            key, sub.encrypt(key, LUT_COBB1));
					}
                    for (int seed : seeds) {
                        System.out.printf("calc key: 0x%08x, from seeds: 0x%08x%n",
                                sub.decrypt(seed, LUT_COBB1), seed);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	private int sub_47B58(int TCNT0H, int it, byte[] LUT) {
	    final int AND_1f = 0x0000001f;
		int TCNT0H_low_xor_w = ((TCNT0H ^ it) & 0x0000FFFF);
		int TCNT0H_low_xor_low_b = (TCNT0H_low_xor_w & 0x000000FF);
		int index_LUT_b_4EBF8 = (TCNT0H_low_xor_low_b & AND_1f);
		byte value1_LUT_b_4EBF8 = LUT[index_LUT_b_4EBF8];
//		System.out.printf("TCNT0H_low_xor_w: 0x%04x%n", TCNT0H_low_xor_w);
//		System.out.printf("TCNT0H_low_xor_low_b: 0x%02x%n", TCNT0H_low_xor_low_b);
//		System.out.printf("index_LUT_b_4EBF8: 0x%02x%n", index_LUT_b_4EBF8);
//		System.out.printf("value1_LUT: 0x%02x%n", value1_LUT_b_4EBF8);
		int TCNT0H_low_shift = TCNT0H_low_xor_w >>> 2;
//		System.out.printf("TCNT0H_low_shift: 0x%04x%n", TCNT0H_low_shift);
		TCNT0H_low_shift = TCNT0H_low_shift >>> 2;
//		System.out.printf("TCNT0H_low_shift: 0x%04x%n", TCNT0H_low_shift);
		int TCNT0H_low_shift_b = (TCNT0H_low_shift & 0x000000FF);
//		System.out.printf("TCNT0H_low_shift_b: 0x%02x%n", TCNT0H_low_shift_b);
		int index_TCNT0H_low_shift_b = (TCNT0H_low_shift_b & AND_1f);
//		System.out.printf("index_TCNT0H_low_shift_b: 0x%02x%n", index_TCNT0H_low_shift_b);
		byte value2_LUT_b_4EBF8 = LUT[index_TCNT0H_low_shift_b];
//		System.out.printf("value2_LUT: 0x%02x%n", value2_LUT_b_4EBF8);
		int TCNT0H_low_xor_hi_b = (TCNT0H_low_xor_w >>> 8);
//		System.out.printf("TCNT0H_low_xor_hi_b: 0x%02x%n", TCNT0H_low_xor_hi_b);
		int index_TCNT0H_low_xor_hi_b = (TCNT0H_low_xor_hi_b & AND_1f);
//		System.out.printf("index_TCNT0H_low_xor_hi_b: 0x%02x%n", index_TCNT0H_low_xor_hi_b);
		byte value3_LUT_b_4EBF8 = LUT[index_TCNT0H_low_xor_hi_b];
//		System.out.printf("value3_LUT: 0x%02x%n", value3_LUT_b_4EBF8);
		int TCNT0H_low_xor_w_bit0 = (TCNT0H_low_xor_w & 0x01);
		int TCNT0H_low_xor_w_bit4 = (TCNT0H_low_xor_w_bit0 << 4);
//		System.out.printf("TCNT0H_low_xor_w_bit4: 0x%02x%n", TCNT0H_low_xor_w_bit4);
		int TCNT0H_low_xor_hi_b_shft = (TCNT0H_low_xor_hi_b >>> 4);
//		System.out.printf("TCNT0H_low_xor_hi_b_shft: 0x%02x%n", TCNT0H_low_xor_hi_b_shft);
		int TCNT0H_low_xor_w_bit4_add_shft = TCNT0H_low_xor_w_bit4 + TCNT0H_low_xor_hi_b_shft; 
		int index_TCNT0H_low_xor_w_bit4_add_shft = (TCNT0H_low_xor_w_bit4_add_shft & AND_1f);
//		System.out.printf("index_TCNT0H_low_xor_w_bit4_add_shft: 0x%02x%n", index_TCNT0H_low_xor_w_bit4_add_shft);
		byte value4_LUT_b_4EBF8 = LUT[index_TCNT0H_low_xor_w_bit4_add_shft];
//		System.out.printf("value4_LUT: 0x%02x%n", value4_LUT_b_4EBF8);
		int value4 = value4_LUT_b_4EBF8 << 12;
		int value3 = value3_LUT_b_4EBF8 << 8;
		int valueWord = value4 + value3;
//		System.out.printf("valueWord 4+3: 0x%04x%n", valueWord);
		int value2 = value2_LUT_b_4EBF8 << 4;
		valueWord = valueWord + value2 + value1_LUT_b_4EBF8;
//		System.out.printf("valueWord 2+1: 0x%04x%n", valueWord);
		int valueLowWord = valueWord >> 3;
//		System.out.printf("valueLowWord: 0x%04x%n", valueLowWord);
		int valueHiWord = valueWord << 13;
//		System.out.printf("valueHiWord: 0x%04x%n", valueHiWord);
		int returnValue = valueHiWord + valueLowWord;
		return returnValue;
	}

    private void transform_kernel_block04(int TCNT0H, boolean doencrypt)
    {
        int i,j;
        int word1,word2,idx2,temp,key16;
        int[] data = new int[4];
        data[0] = (TCNT0H >>> 28) & 0x0000000F; 
        data[1] = (TCNT0H >>> 24) & 0x0000000F; 
        data[2] = (TCNT0H >>> 20) & 0x0000000F; 
        data[3] = (TCNT0H >>> 16) & 0x0000000F; 

        for (i = 0; i < 8; i += 4)
        {

            if (doencrypt)
            {
                word2 = (data[0] << 8) + data[1];
                word1 = (data[2] << 8) + data[3];
                for (j = 1; j <= 4; j++)
                {
                    idx2 = word1 ^ LUT_w_4EBB8[j-1];
                    key16 =
                            LUT_b_4EBF8[(idx2 >> 0) & 0x1F]
                        + (LUT_b_4EBF8[(idx2 >> 4) & 0x1F] << 4)
                        + (LUT_b_4EBF8[(idx2 >> 8) & 0x1F] << 8)
                        + (LUT_b_4EBF8[(((idx2 & 0x1) << 4) + (idx2 >> 12)) & 0x1F] << 12);
                    barrelShiftWordRight(key16);
                    barrelShiftWordRight(key16);
                    barrelShiftWordRight(key16);

                    temp = word1;
                    word1 = key16 ^ word2;
                    word2 = temp;

                }
                data[0] = word1 >> 8;
                data[1] = word1 & 0xFF;
                data[2] = word2 >> 8;
                data[3] = word2 & 0xFF;
            }
            else
            {
                word1 = (data[0] << 8) + data[1];
                word2 = (data[2] << 8) + data[3];
                for (j = 4; j > 0; j--)
                {
                    idx2 = word2 ^ LUT_w_4EBB8[j-1];
                    key16 =
                            LUT_b_4EBF8[(idx2 >> 0) & 0x1F]
                        + (LUT_b_4EBF8[(idx2 >> 4) & 0x1F] << 4)
                        + (LUT_b_4EBF8[(idx2 >> 8) & 0x1F] << 8)
                        + (LUT_b_4EBF8[(((idx2 & 0x1) << 4) + (idx2 >> 12)) & 0x1F] << 12);
                    barrelShiftWordRight(key16);
                    barrelShiftWordRight(key16);
                    barrelShiftWordRight(key16);
                    temp = word2;
                    word2 = key16 ^ word1;
                    word1 = temp;
                }
                data[0] = word2 >> 8;
                data[1] = word2 & 0xFF;
                data[2] = word1 >> 8;
                data[3] = word1 & 0xFF;
            }

            data[0] = (TCNT0H >>> 12) & 0x0000000F; 
            data[1] = (TCNT0H >>> 8) & 0x0000000F; 
            data[2] = (TCNT0H >>> 4) & 0x0000000F; 
            data[3] = (TCNT0H & 0x0000000F); 
        }
    }

    private int convert(int value, int it, byte[] LUT) {
        final int AND_1f = 0x0000001f;
        int value_xord = ((value ^ it) & 0x0000FFFF);
        int valueWord = (LUT[value_xord & AND_1f]) +
        ((LUT[(value_xord >>> 4) & AND_1f]) << 4) +
        ((LUT[(value_xord >>> 8) & AND_1f]) << 8) +
        ((LUT[((value_xord & 0x01) << 4) +
                (value_xord >>> 12) & AND_1f]) << 12);

        int returnValue = barrelShiftWordRight(valueWord);
        returnValue = barrelShiftWordRight(returnValue);
        returnValue = barrelShiftWordRight(returnValue);
        return returnValue;
    }

    private int barrelShiftWordRight(int word)
    {
        if ((word & 1) == 1) {
            word = (word >> 1) + 0x00008000;
        }
        else {
            word = word >> 1;
        }
        return word;
    }
}
